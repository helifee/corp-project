package cn.helife.hibernate.client;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import cn.helife.hibernate.vo.User;

public class Client {

	public static void main(String[] args) {
		
		//��ȡ�����ļ�
		Configuration cfg = new Configuration().configure();
		
		//��������
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		
		Session session = null;
		
		try {
			//����session
			session = sessionFactory.openSession();
			
			//��������
			session.beginTransaction();
			
			User user = new User();
			user.setName("����");
			user.setPassword("111");
			user.setCreateDate(new Date());
			user.setExpireDate(new Date());
			
			session.save(user);
			
			//�ύ����
			session.getTransaction().commit();
			
		} catch(Exception e) {
			e.printStackTrace();
			
			//�ع�����
			session.getTransaction().rollback();
			
		} finally {
			//�ر�����
			if(null != session) {
				if(session.isOpen()) {
					session.close();
				}
			}
		}
	}
}
