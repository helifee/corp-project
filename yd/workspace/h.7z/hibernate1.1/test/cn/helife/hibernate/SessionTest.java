package cn.helife.hibernate;

import junit.framework.TestCase;

public class SessionTest extends TestCase {
	
	public void testSession() {
		System.out.println("-----------testSession---------------");
	}
}
